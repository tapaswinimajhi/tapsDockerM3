﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;

namespace GuidGenerator.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public string Get()
        {
           

            SqlConnection con = new SqlConnection("Data Source=172.20.143.230;Initial Catalog=DOCKER_DB;Persist Security Info = True; User ID = sa; Password =tcube@123");
            //SqlCommand cmd = new SqlCommand();
            //SqlDataReader reader;
            String final;
            //cmd.CommandText = "getGUID"; //Stored Procedure Name
            //cmd.CommandType = CommandType.Text;
            //cmd.Connection = con;
            //con.Open();
            ////reader = cmd.ExecuteReader();
            //// Data is accessible through the DataReader object here.
            //DataSet ds = ds.cmd.ExecuteNonQuery(); ;
            //con.Close();
            //return final;

            DataSet dt = new DataSet();
            SqlCommand cmd = new SqlCommand("getGUID", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@CategoryID", SqlDbType.BigInt, 10).Value = CategoryID;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            //SqlDataReader dreader = cmd.ExecuteReader();

            da.Fill(dt).ToString();
            string s = dt.Tables[0].Rows[0]["GUID"].ToString();
                return s;
        }
        
    }
}
